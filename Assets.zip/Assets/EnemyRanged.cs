using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyRanged : MonoBehaviour
{
    public GameObject bullet;
    GameObject player;
    public float shotDelay;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(shoot());
        player=GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    IEnumerator shoot(){
        yield return new WaitForSeconds(shotDelay);
        if(transform.position.x>player.transform.position.x){
            //shoot to left
            
            Instantiate(bullet,transform.position,transform.rotation * Quaternion.Euler (0f, 0f, 180f));
        }else{
            Instantiate(bullet,transform.position,transform.rotation);
        }
        StartCoroutine(shoot());
    }

}
