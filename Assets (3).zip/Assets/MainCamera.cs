using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCamera : MonoBehaviour
{
    bool shaking=false;
    Vector3 originalPosition;
    // Start is called before the first frame update
    void Start()
    {
        originalPosition=transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if(shaking){
            float x = Random.Range(-1f, 1f) * 0.2f;
            float y = Random.Range(-1f, 1f) * 0.2f;

            transform.position = new Vector3(x, y, -10f);
        }else{
            transform.position=originalPosition;
        }
    }
    public void Shake(float duration, float magnitude)
    {
        shaking=true;
        originalPosition=transform.position;
        StartCoroutine(s());
    }
    IEnumerator s(){
        yield return new WaitForSeconds(0.3f);
        shaking=false;
    }

}
