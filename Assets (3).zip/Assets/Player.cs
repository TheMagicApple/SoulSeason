using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Player : MonoBehaviour
{
    bool movingLeft;
    bool movingRight;
    bool chargingTeleport=false;
    bool forceTeleport=false;
    bool facingLeft=false;
    bool onGround=true;
    float speed=7;
    float teleportDistance=0;
    public GameObject teleportParticle;
    public GameObject teleportLine;
    public Transform attackPos;
    public LayerMask enemies;
    public float attackRange;
    Rigidbody2D r;
    public GameObject camera;
    public GameObject healthBar;
    float health=100;
    int takeDamage=-1;
    int strength=20;
    float maxHealth=100;
    float healthGain=0;
    public static int totalSouls=0;
    public static int souls=0;
    public TMP_Text soulsText;
    bool shopOpen=false;
    public GameObject shop;
    float lifesteal=0.5f;
    bool dead=false;
    public GameObject black;
    int damageToDeal=0;
    int strUpgrades=0;
    int hpUpgrades=0;
    int speUpgrades=0;
    int lifUpgrades=0;
    bool cooldown=false;
    
    // Start is called before the first frame update
    void Start()
    {
        r=GetComponent<Rigidbody2D>();
        /*
        todo:
        DONE 5 fix attack and teleport controls (left and right click)
        4 fix thing where enemy only attacks once on collision and should attack every so often when in collision
        1 kind of annoying how its hard to attack and dodge because when you go the other way to dodge you cant hit the enemy
        2 spider too op??
        DONE 5 maybe make different types of enemies have different appearances?
        DONE 4 make different enemies (king and teleporter) do different amount of melee damage
        2 maybe make shop open a smooth animation?
        3 maybe make the shop get more expensive with each purpose?
        3 maybe make the enemies have more health as time goes on?
        DONE 5 fix the bug where you can see the teleport line when you face left
        4 enemy health bar?
        KINDA 4 balance shop so that upgrades are fair?
        4 game is literally not balanced at all...
        DONE 3 enemies get stuck behind each other when off screen spawning
        3 balance archer?
        DONE 5 enemies go off screen
        2 add button to open shop?
        3 add video to home background/make home background look better
        DONE 5 high score
        DONE 5 tutorial
        3 fix sword bug where you hit things from behind?


        

        
        */
    }

    // Update is called once per frame
    void Update()
    {
        if(!dead){

        
        if(r.velocity.x<0 && transform.position.x<=-12f){
                    r.velocity=new Vector2(0,r.velocity.y);
                }
                 if(r.velocity.x>0 && transform.position.x>=12f){
                    r.velocity=new Vector2(0,r.velocity.y);
                    
                }
        if(transform.position.x>13f){
            transform.position=new Vector3(12,transform.position.y,transform.position.z);
        }
        soulsText.text=""+souls;
        if(Input.GetKeyDown("a")){
            movingLeft=true;
            facingLeft=true;
            if(transform.rotation.eulerAngles.y<0.1f){
                transform.Rotate(0,180,0);
            }
        }
        if(Input.GetKeyDown("d")){
            movingRight=true;
            facingLeft=false;
            if(transform.rotation.eulerAngles.y>179.1f && transform.rotation.eulerAngles.y<180.1f){
                transform.Rotate(0,-180,0);
            }
        }
        if(Input.GetKeyDown("w") && onGround){
            r.AddForce(new Vector2(0,500));
            onGround=false;
        }
        if(Input.GetKeyUp("a")){
            movingLeft=false;
        }
        if(Input.GetKeyUp("d")){
            movingRight=false;
        }
        if(movingLeft){
            transform.position+=transform.right*speed*Time.deltaTime;
        }
        if(movingRight){
            transform.position+=transform.right*speed*Time.deltaTime;
        }

        if(Input.GetMouseButtonDown(1)){
            chargingTeleport=true;
           // teleportParticle.SetActive(true);
            StartCoroutine(teleport());
        }
        
        if(Input.GetMouseButtonUp(1) || forceTeleport){
            if(facingLeft){
                transform.position-=new Vector3(teleportDistance,0,0);
            }else{
                transform.position+=new Vector3(teleportDistance,0,0);
            }
            teleportDistance=0;
            chargingTeleport=false;
            forceTeleport=false;
            teleportLine.transform.localScale=new Vector3(1,1,1);
            //teleportParticle.SetActive(false);
        }

        if(Input.GetMouseButtonDown(0) && !cooldown){
            transform.GetChild(0).GetComponent<Sword>().Swing();
            StartCoroutine(attack());
            cooldown=true;
            StartCoroutine(relax());
            
        }

        if(Input.GetKeyDown("p")){
           shopOpen=!shopOpen;
           if(shopOpen){
shop.SetActive(true);
            Time.timeScale=0;
           }else{
            shop.SetActive(false);
            Time.timeScale=1;
           }
            
        }
        }
    }
    void FixedUpdate(){
        if(chargingTeleport){
            teleportDistance+=0.2f;
            teleportLine.transform.localScale+=new Vector3(0.4f,0,0);
        }
        if(takeDamage>0){
            takeDamage--;
            if(takeDamage==0){
               // health-=20;
               GetComponent<SpriteRenderer>().color=new Color(0.71f,0.61f,0.61f,1);
               StartCoroutine(normalColor());
               healthGain=-1*damageToDeal;
               damageToDeal=0;
            healthBar.transform.localScale=new Vector3(health/100f,1,1);
                takeDamage=-1;
            }
        }
        if(healthGain!=0){
            if(healthGain<0){
                healthGain+=1;
                health-=1;
                if(health<=0){
                    dead=true;
                    black.GetComponent<Black>().active=true;
                }
                if(health>maxHealth){
                    health=maxHealth;
                }
                healthBar.transform.localScale=new Vector3(health/maxHealth,1,1);
                if(healthGain>0){
                    healthGain=0;
                }
            }
            if(healthGain>0){
                healthGain-=1;
                health+=1;
                if(health>maxHealth){
                    health=maxHealth;
                }
                healthBar.transform.localScale=new Vector3(health/maxHealth,1,1);
                if(healthGain<0){
                    healthGain=0;
                }
            }
        }
    }
    IEnumerator relax(){
        yield return new WaitForSeconds(0.3f);
        cooldown=false;
    }
    IEnumerator normalColor(){
        yield return new WaitForSeconds(0.15f);
        GetComponent<SpriteRenderer>().color=new Color(1,1,1,1);

    }
    IEnumerator teleport(){
        yield return new WaitForSeconds(0.8f);
        if(chargingTeleport){
            forceTeleport=true;
        }
    }
    IEnumerator attack(){
        yield return new WaitForSeconds(0.2f);
        Collider2D[] enemiesToDamage=Physics2D.OverlapCircleAll(attackPos.position,attackRange,enemies);
            for(int i=0;i<enemiesToDamage.Length;i++){
                enemiesToDamage[i].GetComponent<EnemyMovement>().TakeDamage(strength);
                
                healthGain=strength*lifesteal;
                if(health>maxHealth){
                    health=maxHealth;
                }
            healthBar.transform.localScale=new Vector3(health/100f,1,1);
                //Debug.Log("ATTACK"+enemiesToDamage.Length);

            }
            //Debug.Log("HELLO");
            if(enemiesToDamage.Length>0){
                camera.GetComponent<MainCamera>().Shake(100f,100f);
                //Debug.Log("SHOOK");
            }
    }
    void OnCollisionEnter2D(Collision2D c){
        if(c.collider.tag=="Ground"){
            onGround=true;
        }
        if (c.collider.tag == "Enemy") {
            takeDamage=6;
            damageToDeal+=c.collider.gameObject.GetComponent<EnemyMovement>().damage;
            //r.velocity = 5*(transform.position-c.gameObject.transform.position);
        } 
        

    }
    void OnTriggerEnter2D(Collider2D c){
       // Debug.Log("TRIGGERED");
        if(c.tag=="Bullet"){
            healthGain=-5f;
            Destroy(c.gameObject);
        }
       
    }
    void OnCollisionExit2D(Collision2D c){
        if(c.collider.tag=="Enemy"){
            takeDamage=-1;
            damageToDeal-=c.collider.gameObject.GetComponent<EnemyMovement>().damage;
        }
    }
    public void explode(){
        healthGain=-25f;
    }
    public void moreStrength(){
        int soulCost=strUpgrades/2+1;
        if(souls>=soulCost){
            souls-=soulCost;
            strength+=5;
            strUpgrades++;
        }
        
    }
    public void moreHP(){
        int soulCost=hpUpgrades/2+1;
        if(souls>=soulCost){
            souls-=soulCost;
            maxHealth+=10;
            hpUpgrades++;
        }
    }
    public void moreSpeed(){
        int soulCost=speUpgrades/2+1;
        if(souls>=soulCost){
           souls-=soulCost;
            speed+=1f;
            speUpgrades++;
        }
    }
    public void moreLifesteal(){
       int soulCost=lifUpgrades/2+1;
       if(souls>=soulCost){
        souls-=soulCost;
        lifesteal+=0.1f;
        lifUpgrades++;
       }
        
    }


}
