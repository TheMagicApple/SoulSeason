using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ButtonManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void play(){
        Player.souls=0;
        Player.totalSouls=0;
        int firstTime=PlayerPrefs.GetInt("FirstTime",0);
        if(firstTime==0){
            PlayerPrefs.SetInt("FirstTime",1);
            SceneManager.LoadScene("Tutorial");
        }else{
            SceneManager.LoadScene("Game");
        }
        
    }
    public void home(){
        SceneManager.LoadScene("Home");
    }
    public void tutorial(){
        SceneManager.LoadScene("Tutorial");
    }
}
