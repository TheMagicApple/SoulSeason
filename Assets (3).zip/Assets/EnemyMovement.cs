using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public float speed;
    public int enemyType;
    public int damage;
    private GameObject player;
    private Rigidbody2D rb;
    private int jumpTimer;
    public ParticleSystem hurt;
    public int hp=200;
    private int hurtCounter;
    private SpriteRenderer spriteRenderer;
    private Color enemyColor;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        rb = GetComponent<Rigidbody2D>();
        jumpTimer = 800;
        spriteRenderer = GetComponent<SpriteRenderer>();
        enemyColor = spriteRenderer.color;
    }

    void Update() {
        jumpTimer--;

    }
    // Update is called once per frame
    void FixedUpdate()
    {
                //Follows the player
                if (enemyType >= 0) {
                    if (player.transform.position.x < transform.position.x) {
                        transform.Translate(-1*speed,0f,0f);
                    }
                    else {
                        transform.Translate(speed,0f,0f);
                    }
                }
                if(rb.velocity.x<0 && transform.position.x<=-12f){
                    rb.velocity=new Vector2(0,rb.velocity.y);
                }
                 if(rb.velocity.x>0 && transform.position.x>=12f){
                    rb.velocity=new Vector2(0,rb.velocity.y);
                    
                }
                
                if(enemyType==2){
                    if (jumpTimer <= 500) {
                        if (player.transform.position.x < transform.position.x) {
                            rb.AddForce(new Vector3(-800f,500f,0f));
                        }else{
                            rb.AddForce(new Vector3(800f,500f,0f));
                        }
                    
                        jumpTimer = 800;
                    }
                }else if(enemyType!=4 && enemyType!=1){
                    if (jumpTimer <= 0) {
                        rb.AddForce(new Vector3(0f,500f,0f));
                        jumpTimer = 800;
                    }
                }else if(enemyType!=1){
                    if(jumpTimer<=0){
                        //teleport!
                        float newX=Random.Range(-10.75f,10.75f);
                        if(player.transform.position.x>transform.position.x){
                            newX=Random.Range(player.transform.position.x,10.75f);
                            
                        }else{
                           newX=Random.Range(-10.75f,player.transform.position.x);
                            
                        }
                        transform.position=new Vector3(newX,transform.position.y,transform.position.z);
                        jumpTimer=600;
                    }
                }
               
                
            if (hurtCounter > 0) {
                hurtCounter--;
                if (hurtCounter<=0) {
                    spriteRenderer.color = enemyColor;
                }
            }
}
                
        
        public void TakeDamage(int damage){
            hurt.Play();
                rb.velocity = 5*(transform.position-player.transform.position);
                Debug.Log("KNOCKBACK");
                Debug.Log(rb.velocity);
                hurtCounter = 25;
                spriteRenderer.color = new Color(255,255,255);
                hp-=damage;
                if (hp <= 0) {
                    Player.souls++;
                    Player.totalSouls++;
                    gameObject.SetActive(false);
                }
        }
        
    void OnTriggerEnter2D(Collider2D c){
        /*
        if(c.gameObject.tag=="Sword"){
            if (c.gameObject.GetComponent<Sword>().swinging) {
               hurt.Play();
                rb.velocity = 2*(transform.position-player.transform.position);
                hurtCounter = 25;
                spriteRenderer.color = new Color(255,255,255);
                hp-=1;
                if (hp <= 0) {
                    gameObject.SetActive(false);
                }

            }
        }
        */

    }

}