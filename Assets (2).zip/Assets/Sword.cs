using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword : MonoBehaviour
{
    public bool swinging=false;
    float swingSpeed=7f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(swinging){
            transform.position+=transform.right*swingSpeed*Time.deltaTime;
            if(transform.localPosition.x>2.5f){
                swingSpeed=-7f;
            }
            if(transform.localPosition.x<1.44f && swingSpeed<0){
                swinging=false;
                swingSpeed=7f;
            }
            /*
            transform.Rotate(0,0,-950*Time.deltaTime);
            if(transform.rotation.eulerAngles.z<25){
                swinging=false;
            }
            */
        }
    }
    public void Swing(){
        //swing!
        //transform.Rotate(0,0,135);
        swinging=true;
    }
}
