using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Black : MonoBehaviour
{
    public bool active;
    float alpha=0;
    public GameObject deathPanel;
    public TMP_Text soulsCollected;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(active){
            
            GetComponent<SpriteRenderer>().color=new Color(0,0,0,alpha);
           alpha+=0.02f;
            if(alpha>=0.94f){
                alpha=0.94f;
                GetComponent<SpriteRenderer>().color=new Color(0,0,0,alpha);
                active=false;
                deathPanel.SetActive(true);
                soulsCollected.text="Souls Collected: "+Player.totalSouls;
                int highScore=PlayerPrefs.GetInt("HighSouls",0);
                if(Player.totalSouls>highScore){
                    PlayerPrefs.SetInt("HighSouls",Player.totalSouls);
                }
            }
        }
    }
}
