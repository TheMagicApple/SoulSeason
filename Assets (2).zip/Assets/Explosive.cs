using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosive : MonoBehaviour
{
    public ParticleSystem particles;
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<Rigidbody2D>().AddForce(new Vector2(transform.right.x*5,8),ForceMode2D.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D c){
        if(c.tag=="Ground"|| c.tag=="Player"){
            particles.Play();
            GetComponent<Rigidbody2D>().gravityScale=0;
            GetComponent<Rigidbody2D>().velocity=new Vector2(0,0);
            GetComponent<SpriteRenderer>().enabled=false;
            GameObject player=GameObject.Find("Player");
            if(Mathf.Abs(player.transform.position.x-transform.position.x)<3f){
                player.GetComponent<Player>().explode();
            }
            Destroy(gameObject,0.5f);
        }
        
    }
}
