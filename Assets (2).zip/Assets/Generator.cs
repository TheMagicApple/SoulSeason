using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generator : MonoBehaviour
{
    public GameObject melee;
    public GameObject ranged;
    public GameObject spider;
    public GameObject exploder;
    public GameObject teleporter;
    public GameObject king;
    float cooldown=5;
    int lowTier=0;
    int tier=1;
    int nSpawn=1;
    int wave=18;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(spawn());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    IEnumerator spawn(){
        yield return new WaitForSeconds(cooldown);
        for(int i=0;i<nSpawn;i++){
            int enemy=Random.Range(lowTier,tier);
            int direction=Random.Range(0,2);
            GameObject enemySpawn=melee;
            if(enemy==0){
                enemySpawn=melee;
            }
            if(enemy==1){
                enemySpawn=ranged;
            }
            if(enemy==2){
                enemySpawn=spider;
            }
            if(enemy==3){
                enemySpawn=exploder;
            }
            if(enemy==4){
                enemySpawn=teleporter;
            }
            if(enemy==5){
                enemySpawn=king;
            }
            Vector3 spawnPosition=new Vector3(Random.Range(14f,23f),Random.Range(-2f,1f),0);
            if(direction==0){
                spawnPosition=new Vector3(spawnPosition.x*-1,spawnPosition.y,spawnPosition.z);
            }
            Instantiate(enemySpawn,spawnPosition,Quaternion.identity);


        }
        
        wave++;
         if(wave==2){
            cooldown=7;
            nSpawn=3;
        }
        if(wave==3){
            tier=2;
            
        }
        if(wave==4){
            lowTier=1;
        }
        if(wave==5){
            nSpawn=4;
            cooldown=5;
            lowTier=0;
            tier=1;
        }
        if(wave==6){
            tier=3;
            cooldown=8;
            nSpawn=3;
        }
        if(wave==7){
            nSpawn=4;
            cooldown=6;
            lowTier=1;
        }
        if(wave==8){
            nSpawn=2;
            lowTier=0;
            tier=1;
            cooldown=0;
        }
        if(wave==9){
            nSpawn=3;
            tier=3;
            cooldown=5;
        }
        if(wave==10){
            lowTier=2;
            cooldown=0;
            nSpawn=2;
        }
        if(wave==11){
            lowTier=3;
            tier=4;
            cooldown=0;
            nSpawn=1;
        }
        if(wave==12){
            nSpawn=2;
            lowTier=1;
            cooldown=4;
        }
        if(wave==13){
            nSpawn=3;
            lowTier=2;
            tier=5;
            cooldown=2;
        }
        if(wave==14){
            nSpawn=4;
            lowTier=0;
            cooldown=4;
        }
        if(wave==15){
            lowTier=5;
            tier=6;
            nSpawn=1;
            cooldown=10;
        }
        if(wave==16){
            lowTier=1;
            tier=5;
            nSpawn=4;
            cooldown=2;
        }
        if(wave==17){
            lowTier=0;
            tier=1;
            nSpawn=8;
            cooldown=2;
        }
        if(wave>=18){
            nSpawn=(wave-9);
            cooldown=10;
            lowTier=0;
            tier=6;
        }
    StartCoroutine(spawn());
        
    }
    
}
